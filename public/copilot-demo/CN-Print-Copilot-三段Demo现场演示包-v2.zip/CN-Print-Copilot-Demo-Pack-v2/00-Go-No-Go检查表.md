# 演示前 Go / No-Go 检查表

建议在正式分享前一天完整走一遍，正式分享前 30 分钟再快速复核。

## Go：满足后可以现场演示

- [ ] 使用正式演示账号登录 `https://microsoft365.com/chat`。
- [ ] 页面显示工作账号，并能正常使用 Copilot Chat。
- [ ] Demo 2 的 4 个文件都能成功附加或从工作资料中选择。
- [ ] Copilot 回答中可以显示引用，且至少两条引用能够打开原文件。
- [ ] 左侧能看到 Agents / New agent，或已有可进入的 Agent Builder 入口。
- [ ] Agent Builder 允许连接本包中的 4 份批准知识文件。
- [ ] Demo 3 的 4 份批准知识文件已提前放入演示账号可访问的 SharePoint / OneDrive 位置，并完成一次检索测试。
- [ ] Try it 中四类测试均跑过一遍。
- [ ] 浏览器缩放 100%，通知关闭，敏感窗口关闭。
- [ ] `00-现场演示控制台.html` 已打开，三个 Demo 卡均可复制提示词。
- [ ] PPT、Copilot 页面、素材文件夹三个窗口已经按演示顺序打开。

## No-Go：出现任一项，不承诺全程 Live

- [ ] 演示账号没有 Microsoft 365 Copilot 工作数据能力，无法使用工作资料。
- [ ] 4 个文件无法上传、无法被检索，或引用无法打开。
- [ ] Agent Builder / New agent 被管理员关闭或当前许可证不可用。
- [ ] Agent Builder 无法访问预先准备的 SharePoint / OneDrive 知识位置。
- [ ] 中文自然语言创建 Agent 的体验在当前账号不可用，且未准备手动 Configure 路径。
- [ ] 网络明显不稳定，连续两次请求超过 30 秒。

## No-Go 时的切换原则

- Demo 1：仍可 Live；若慢，展示三轮提示词并口头对比。
- Demo 2：退到 Copilot Chat 附件模式；仍不可用则展示黄金参考答案并手动点开源文件。
- Demo 3：展示 Instructions、Knowledge、Starter prompts 和四类测试，不假装 Agent 已创建成功。

## 最终判定

- 三段全部 Go：按 PPT 正常 Live。
- Demo 1、2 Go，Demo 3 No-Go：前两段 Live，第三段用配置卡 + 测试卡。
- Demo 2 引用不可用：不要宣称“可追溯已验证”，改为现场人工打开源文件核对。
